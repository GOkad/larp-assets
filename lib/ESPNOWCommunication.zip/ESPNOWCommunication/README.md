# ESP-NOW Communication library for ESP8266 and ESP32

# The README also doubles as a CHANGELOG

## Version 1.1.0 [2022-07-XX]
### Added
- `ESPNOWCommunication` class
- `initialize` method

## Version 1.0.0 [2022-07-15]
- Initial Setup